const notes = [
    
    {
        text: `Hello I am Piyush And i am making notes App.
                            SUBSCRIBE to AbNormal to see more of such videos and
                            to learn.`,
        date: 1443657600000,
    },
    {
        text: `In the heart of the bustling city, amidst the cacophony of honking horns and chattering pedestrians, stood an old bookstore. Its weathered facade and creaky wooden door held a charm that beckoned to passersby.`,
        date: 1577836800000,
    },
    {
        text: `Evelyn, the shop's owner, spent her days immersed in the world of words. Her fingers danced over the spines of books as she shelved new arrivals and dusted the old ones.`,
        date: 1609459200000,
    },
    {
        text: `One rainy afternoon, a young man named Leo stumbled into the store, drenched and shivering. His eyes widened at the sight of the floor-to-ceiling shelves filled with books of every genre. As he wandered through the aisles, he found himself drawn to a dusty old volume `,
        date: 1659372000000,
    },
    {
        text: `Evelyn noticed Leo's fascination and approached him with a warm smile.`,
        date: 1583020800000,
    },
    {
        text: `hello everyone heheheheheheh, Leo's fascination and approached him with a warm smile.`,
        date: 1622378280000,
    },
];

export { notes };
